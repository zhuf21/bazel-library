Array<int, 1, 6> a(1, 2, 3, 4, 5, 6);
Array<int, 3, 1> b {1, 2, 3};
cout << a << "\n\n" << b << endl;
